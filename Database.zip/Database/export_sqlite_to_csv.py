import sqlite3, csv, os

DB_FILE = "appEconnectDB_X.db"  # change to your actual SQLite filename, e.g., Clarifi.db

if not os.path.exists(DB_FILE):
    raise FileNotFoundError(f"Database not found: {os.path.abspath(DB_FILE)}")

conn = sqlite3.connect(DB_FILE)
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
tables = [r[0] for r in cur.fetchall()]

print(f"Found tables: {tables}")
for t in tables:
    rows = cur.execute(f"SELECT * FROM {t}")
    cols = [d[0] for d in rows.description]
    out_path = f"{t}.csv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in rows:
            w.writerow(r)
    print(f"Exported {out_path}")

conn.close()
print("Done.")
 